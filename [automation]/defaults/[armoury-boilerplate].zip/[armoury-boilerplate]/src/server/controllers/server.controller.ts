import { FiveMController } from '@core/decorators/armoury.decorators';
import { ServerController } from '@core/server/server.controller';

@FiveMController()
export class Server extends ServerController {
}