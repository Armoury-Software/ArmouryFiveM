import { ServerController } from '../../../../[utils]/server/server.controller';

export class Server extends ServerController {
}