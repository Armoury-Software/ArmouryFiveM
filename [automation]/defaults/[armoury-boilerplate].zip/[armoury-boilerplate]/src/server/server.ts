import { Server } from "./controllers/server.controller";

// eslint-disable-next-line no-unused-vars
const server = new Server();