import { Client } from './controllers/client.controller';

// eslint-disable-next-line no-unused-vars
const client = new Client();