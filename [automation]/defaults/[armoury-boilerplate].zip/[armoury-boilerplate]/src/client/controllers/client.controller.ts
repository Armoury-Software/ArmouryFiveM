import { ClientController } from '../../../../[utils]/client/client.controller';

export class Client extends ClientController {

}